"""
Created on Wed Jun 21 12:25:40 2017

@author: Master Shi
"""
from pulp import *
from microgrid import *
import pandas as pd
import json
import math
import copy

'''Constrcut the microgrid devices and utility prices'''
pv1 = PV()
es1 = electricStorage()
absc1 = absorptionChiller()
bol1 = boiler()
hs1 = heatStorage()
cs1 = coldStorage()
ac1 = airConditioner()
gt1 = gasTurbine()
ut = utility()
inv = inverter()
'''save the parameters'''
parameters = {"光伏":pv1.show(),
             "储能电池":es1.show(),
             "吸收式制冷机":absc1.show(),
             "辅助锅炉":bol1.show(),
             "储热装置":hs1.show(),
             "冰蓄冷装置":cs1.show(),
             "中央空调":ac1.show(),
             "燃气轮机":gt1.show(),
             "变流器":inv.show(),
             "燃气价格等":ut.show()}
with open('parameters.json','w',encoding='UTF-8') as f:
    json.dump(parameters,f)

'''DATA LOADER'''
microgrid_data = pd.read_csv('input.csv')
acload = microgrid_data['交流负荷'].tolist()
dcload = microgrid_data['直流负荷'].tolist()
pv1.output = microgrid_data['光伏出力'].tolist()
ut.buy_price = microgrid_data['电价'].tolist()
cold_load = microgrid_data['冷负荷'].tolist()
water_heat = microgrid_data['热水负荷'].tolist()


'''Construct the OptimalDispatch linear programming model'''
optimalDispatch = LpProblem('optimalDisaptch',LpMinimize)


'''Define the variables'''
power_es1 = list()
power_absc1 = list()
power_bol1 = list()
power_hs1 = list()
power_cs1 = list()
coldintotank = list()
coldoutoftank = list()
power_ac1 = list()
power_gte1 = list()
om_es1 = list()
om_absc1 = list()
om_bol1 = list()
om_hs1 = list()
om_cs1 = list()
om_ac1 = list()
om_gte1 = list()
power_utility = list()
dc = list()
z_pwut = list()
det_pwut_l = list()
det_pwut_u = list()
aux_pwst = list() ##convex
z_iceplus = list()
z_iceminus = list()
det_ice = list()
z_acdc = list()
det_acdc = list()
for i in range(96):
    #Regular variables
    power_es1.append(LpVariable('electricStorage1Power_'+str(i),es1.Pmin,es1.Pmax)) ##
    power_absc1.append(LpVariable('absorptionChiller1Power_'+str(i),lowBound=0))  ##
    power_bol1.append(LpVariable('boiler1Power_'+str(i),bol1.Pmin,bol1.Pmax))  ##
    power_hs1.append(LpVariable('heatStorage1Power_'+str(i),hs1.Hmin,hs1.Hmax))  ##
    power_cs1.append(LpVariable('coldStorage1Power_'+str(i),0,cs1.Hmax))  ##
    power_ac1.append(LpVariable('airConditionerPower_'+str(i),0,ac1.Pmax))  ##
    power_gte1.append(LpVariable('gasTurbineElectricalPower_'+str(i),gt1.Pmin,gt1.Pmax))  ##
    power_utility.append(LpVariable('utilityPower_'+str(i))) ##
    dc.append(LpVariable('DCnetload_'+str(i))) ## AC-DC when >0, DC-AC when <0

    #OM variables
    om_es1.append(LpVariable('OMes_'+str(i)))
    om_absc1.append(LpVariable('OMabsc_'+str(i)))
    om_bol1.append(LpVariable('OMbol_'+str(i)))
    om_hs1.append(LpVariable('OMhs_'+str(i)))
    om_cs1.append(LpVariable('OMcs_'+str(i)))
    om_ac1.append(LpVariable('OMac_'+str(i)))
    om_gte1.append(LpVariable('OMgte_'+str(i)))
    #deal with piecewise linear function
    '''of Utility power sell/buy price difference'''
    z_pwut.append(LpVariable('utilityAuxPower_'+str(i))) ##
    det_pwut_l.append(LpVariable('utilityAuxPowerLowerBound_'+str(i),cat=LpBinary))
    det_pwut_u.append(LpVariable('utilityAuxPowerUpperBound_'+str(i),cat=LpBinary))

    '''of depreciation cost '''
    aux_pwst.append(LpVariable('electricStorageAuxiliaryVariable_'+str(i),lowBound=0)) ##

    '''of cold storage input/output efficiency difference in equality constraints '''
    z_iceplus.append(LpVariable('icePowerplus_'+str(i)))  ##
    z_iceminus.append(LpVariable('icePowerminus_' + str(i)))
    det_ice.append(LpVariable('iceSign'+str(i),cat=LpBinary))
    coldintotank.append(LpVariable('coldintotank_'+str(i),lowBound=0))
    coldoutoftank.append(LpVariable('coldoutoftank_'+str(i),lowBound=0))
    '''of DC/AC and AC/DC conversion efficiency difference'''
    z_acdc.append(LpVariable('ACDC_'+str(i)))
    det_acdc.append((LpVariable('acdcSign'+str(i),cat=LpBinary)))

'''Define the objectives'''
optimalDispatch += lpSum(om_es1) \
    + lpSum(om_absc1) \
    + lpSum(power_bol1) \
    + lpSum(om_hs1) \
    + lpSum(om_cs1) \
    + lpSum(om_ac1) \
    + lpSum(om_gte1) \
    + lpSum(z_pwut) \
    + lpSum(aux_pwst) \
    + lpSum(power_gte1)*(ut.gas_price*0.25/gt1.efficiency) \
    + lpSum(power_bol1)*(ut.gas_price*0.25/bol1.efficiency)

'''Define the constraints'''
'''of Electricity'''
es1selfrelease = [math.pow((1-es1.selfRelease),95 - i) for i in range(96)]
for i in range(96):
    ## ac power balance
    optimalDispatch += power_utility[i] + power_gte1[i] == acload[i] + z_acdc[i] + power_ac1[i] + power_cs1[i] + 0.025*(ac1.EER+1)*power_ac1[i]
    ## dc power balance
    optimalDispatch += dc[i] + pv1.output[i] == dcload[i] + power_es1[i]
    ## MAX-MIN power bound constraints already represented in LpVariables
    ## Electrical Storage capacity constraint
    ##optimalDispatch += 0.25*lpSum(power_es1[0:i+1])/es1.capacity + es1.SOCint <= es1.SOCmax
    ##optimalDispatch += 0.25*lpSum(power_es1[0:i+1])/es1.capacity + es1.SOCint >= es1.SOCmin
    optimalDispatch += 0.25*lpDot(power_es1[0:i+1],es1selfrelease[-i-2:-1])/es1.capacity + es1.SOCint <= es1.SOCmax
    optimalDispatch += 0.25*lpDot(power_es1[0:i + 1],es1selfrelease[-i-2:-1])/es1.capacity + es1.SOCint >= es1.SOCmin
    ## Electrical Storage power changing rate constraint
    if i >= 1:
        optimalDispatch += power_es1[i] - power_es1[i-1] >= -es1.maxDetP
        optimalDispatch += power_es1[i] - power_es1[i - 1] <= es1.maxDetP
    ## Electrical Storage Zero constraint
optimalDispatch += lpSum(power_es1) == 0

'''of Heat'''
for i in range(96):
    ## heat balance
    optimalDispatch += power_gte1[i]*gt1.HER*gt1.heat_recycle + power_bol1[i] - power_hs1[i] - power_absc1[i] >= water_heat[i]
    ## heat storage capacity constraint
    optimalDispatch += 0.25*lpSum(power_hs1[0:i+1])/hs1.capacity + hs1.Tint <= hs1.Tmax
    optimalDispatch += 0.25 * lpSum(power_hs1[0:i+1]) / hs1.capacity + hs1.Tint >= hs1.Tmin
## heat Storage Zero constraint
optimalDispatch += lpSum(power_hs1) == 0

'''of Cold'''
for i in range(96):
    ## cold balance
    optimalDispatch += power_absc1[i]*absc1.COP_htc + coldoutoftank[i] + (power_cs1[i]*cs1.EER-coldintotank[i])+ power_ac1[i]*ac1.EER == cold_load[i]
    optimalDispatch += power_cs1[i] * cs1.EER >= coldintotank[i]
    if cs1.mode == '串联':
        optimalDispatch += coldoutoftank[i] == cs1.Partition * (power_cs1[i]*cs1.EER-coldintotank[i])
    ## cold storage capacity constraint
    optimalDispatch += 0.25 * (lpSum(coldintotank[0:i+1])-lpSum(coldoutoftank[0:i+1])) / cs1.capacity + cs1.Tint <= cs1.Tmax
    optimalDispatch += 0.25 * (lpSum(coldintotank[0:i+1])-lpSum(coldoutoftank[0:i+1])) / cs1.capacity + cs1.Tint >= cs1.Tmin
## cold storge zero constraint
optimalDispatch += lpSum(coldintotank)-lpSum(coldoutoftank) == 0

'''of OM cost'''
for i in range(96):
    optimalDispatch += om_es1[i] >= power_es1[i] * es1.om
    optimalDispatch += om_es1[i] >= -power_es1[i] * es1.om
    optimalDispatch += om_absc1[i] >= power_absc1[i] * absc1.om
    optimalDispatch += om_absc1[i] >= -power_absc1[i] * absc1.om
    optimalDispatch += om_bol1[i] >= power_bol1[i] * bol1.om
    optimalDispatch += om_bol1[i] >= -power_bol1[i] * bol1.om
    optimalDispatch += om_hs1[i] >= power_hs1[i] * hs1.om
    optimalDispatch += om_hs1[i] >= -power_hs1[i] * hs1.om
    optimalDispatch += om_cs1[i] >= power_cs1[i] * cs1.om
    optimalDispatch += om_cs1[i] >= -power_cs1[i] * cs1.om
    optimalDispatch += om_ac1[i] >= power_ac1[i] * ac1.om
    optimalDispatch += om_ac1[i] >= -power_ac1[i] * ac1.om
    optimalDispatch += om_gte1[i] >= power_gte1[i] * gt1.om
    optimalDispatch += om_gte1[i] >= -power_cs1[i] * gt1.om


'''of auxuliary variables'''

bigM = 10000000
for i in range(96):
    ## Utility power sell/buy price difference
    optimalDispatch += det_pwut_l[i] + det_pwut_u[i] == 0
    optimalDispatch += power_utility[i] >= 0 - 10*bigM*(1-det_pwut_u[i])
    optimalDispatch += power_utility[i] >= - bigM - 10*bigM * (1 - det_pwut_l[i])
    optimalDispatch += power_utility[i] <= bigM + 10*bigM * (1 - det_pwut_u[i])
    optimalDispatch += power_utility[i] <= 0 + 10*bigM * (1 - det_pwut_l[i])
    optimalDispatch += z_pwut >= ut.buy_price[i]*power_utility[i] - bigM*(1-det_pwut_u[i])
    optimalDispatch += z_pwut >= ut.sell_price * power_utility[i] - bigM * (1 - det_pwut_l[i])

    ##depreciation cost
    optimalDispatch += aux_pwst[i] >= es1.Cbw*power_es1[i]

    ##ice det_ice = 1 if power_cs1 <= 0
    optimalDispatch += coldintotank[i] <= (1-det_ice[i])*bigM
    optimalDispatch += coldoutoftank[i]  <= det_ice[i]*bigM


    ##dc-ac det_acdc = 1 if dc < 0
    optimalDispatch += dc[i] + bigM*det_acdc[i] >= 0
    optimalDispatch += dc[i] <= bigM*(1 - det_acdc[i])
    optimalDispatch += z_acdc[i] - dc[i]*inv.dc_ac_efficiency <= bigM*(1-det_acdc[i] )
    optimalDispatch += z_acdc[i] - dc[i] * inv.dc_ac_efficiency >= -bigM * (1 - det_acdc[i])
    optimalDispatch += inv.ac_dc_efficiency * z_acdc[i] - dc[i] <= bigM*det_acdc[i]
    optimalDispatch += inv.ac_dc_efficiency * z_acdc[i] - dc[i] >= -bigM * det_acdc[i]
'''
TestOnlyCode
for i in range(96):
    optimalDispatch += z_pwut == ut.buy_price[i] * power_utility[i]
    optimalDispatch += aux_pwst[i] >= es1.Cbw * power_es1[i]
    optimalDispatch += inv.ac_dc_efficiency * z_acdc[i] == dc[i]
    optimalDispatch +=  -cs1.EER * z_ice[i] == power_cs1[i]
'''
'''Take a beer and wait for the result ready in the bed'''
optimalDispatch.solve(CPLEX_CMD(msg=1))
es1.result = pd.Series([x.varValue for x in power_es1])
absc1.result = pd.Series([x.varValue for x in power_absc1])
bol1.result = pd.Series([x.varValue for x in power_bol1])
hs1.result = pd.Series([x.varValue for x in  power_hs1])
cs1.result_electricity = pd.Series([x.varValue for x in power_cs1])
cs1.result_cold = pd.Series([x.varValue for x in coldoutoftank]) + pd.Series([x.varValue for x in power_cs1])*cs1.EER - pd.Series([x.varValue for x in coldintotank])
cs1.result_stored = pd.Series([x.varValue for x in coldintotank]) - pd.Series([x.varValue for x in coldoutoftank])
ac1.result = pd.Series([x.varValue for x in power_ac1])
gt1.result = pd.Series([x.varValue for x in power_gte1])
ut.result = pd.Series([x.varValue for x in power_utility])
inv.result = pd.Series([x.varValue for x in dc])
desiredpower = copy.deepcopy(ut.result)
for index, x in enumerate(desiredpower):
    if x > 3500:
        desiredpower[index] *= 0.8

df= pd.DataFrame()
df['电网购电功率'] = ut.result
df['电储能充放电功率'] = es1.result
df['燃气轮机发电功率'] = gt1.result
df['空调制冷耗电功率'] = ac1.result
df['空调制冷量'] = ac1.result*ac1.EER
df['冰蓄冷供冷功率'] = cs1.result_cold
df['冰蓄冷耗电量'] = cs1.result_electricity
df['冰蓄冷储冷量'] = cs1.result_stored
df['吸收式制冷机制冷量'] = absc1.result * absc1.COP_htc
df['余热锅炉热功率'] = gt1.result*gt1.HER*gt1.heat_recycle
df['燃气锅炉热功率'] = bol1.result
df['热储能功率'] = hs1.result
df['电价'] = pd.Series(ut.buy_price)
df['期望功率'] = desiredpower
df.to_excel('output.xlsx')